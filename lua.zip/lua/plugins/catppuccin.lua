return {
  "catppuccin/nvim",
  name = "catppuccin",
  priority = 1000, -- Load this first before all other plugins
  config = function()
    require("catppuccin").setup({
      flavour = "mocha", -- latte, frappe, macchiato, mocha
      transparent_background = false,
      term_colors = true,
      integrations = {
        cmp = true,
        gitsigns = true,
        nvimtree = true,
        treesitter = true,
        notify = false,
        mini = {
          enabled = true,
          indentscope_color = "",
        },
        -- For VimTeX users:
        vimtex = true,
      },
    })

    -- setup must be called before loading the colorscheme
    vim.cmd.colorscheme "catppuccin"
  end,
}
