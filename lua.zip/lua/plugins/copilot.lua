return {
  "github/copilot.vim",
  -- No 'config = function()...' needed for basic installation
  -- You can add optional settings in the 'init' function
  init = function()
    -- Example: Disable copilot for specific filetypes
    -- vim.g.copilot_filetypes = { ["markdown"] = false }
  end,
}
